// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:flutter/material.dart';
import 'package:flutter_test_project/constants/app_colors.dart';
import 'package:flutter_test_project/services/firestore_%20services.dart';
import 'package:flutter_test_project/widgets/custom_button.dart';
import 'package:flutter_test_project/widgets/custom_cart.dart';
import 'package:hive/hive.dart';

final _cartbox = Hive.box('cartBox');

// ignore: must_be_immutable
class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  double totalPrice = 0.0;
  List<Map<String, dynamic>> cartItems = [];

  @override
  void initState() {
    super.initState();
    fetchCartData();
  }

  Future<void> fetchCartData() async {
    cartItems = await Firestore().getCartItems();
    calculateTotalPrice();
    setState(() {});
  }

  void calculateTotalPrice() {
    totalPrice = 0.0;
    for (var item in cartItems) {
      totalPrice += item['price'] * item['quantity'];
    }
  }

  void updateQuantity(String productId, int newQuantity) {
    setState(() {
      final index = cartItems.indexWhere(
        (item) => item['productId'] == productId,
      );
      if (index != -1) {
        if (newQuantity <= 0) {
          cartItems.removeAt(index);
          _cartbox.delete(productId);
        } else {
          cartItems[index]['quantity'] = newQuantity;
          _cartbox.put(productId, newQuantity);
        }
        calculateTotalPrice();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            '${cartItems.length} items',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w400,
              color: AppColors.textinputColor,
            ),
          ),
        ),
        Expanded(
          child: cartItems.isEmpty
              ? Center(
                  child: Text(
                    'Your cart is empty',
                    style: TextStyle(
                      color: AppColors.textinputColor,
                      fontSize: 18,
                    ),
                  ),
                )
              : ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder: (context, index) {
                    final item = cartItems[index];
                    return CustomCart(
                      imageUrl: item['imageUrl'],
                      productName: item['productName'],
                      price: item['price'],
                      quantity: item['quantity'],
                      onAdd: () => updateQuantity(
                        item['productId'],
                        item['quantity'] + 1,
                      ),
                      onRemove: () => updateQuantity(
                        item['productId'],
                        item['quantity'] - 1,
                      ),
                    );
                  },
                ),
        ),
        Container(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Total Price: \$${totalPrice.toStringAsFixed(2)}',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textinputColor,
                ),
              ),
              const Spacer(),
              CustomElevatedButton(
                icon: Icon(Icons.payment, color: AppColors.textColor),
                text: 'Checkout',
                onPressed: () {},
                width: 155,
                height: 45,
                borderredius: 10,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
