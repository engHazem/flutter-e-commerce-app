import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

final _cartbox = Hive.box('cartBox');

void showStatusSnackBar({
  required BuildContext context,
  required bool isSuccess,
  required String message,
}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, style: const TextStyle(color: Colors.white)),
      backgroundColor: isSuccess ? Colors.green[800] : Colors.red[800],
      duration: const Duration(seconds: 2),
    ),
  );
}

void clearAllControllers({required List<TextEditingController> controllers}) {
  for (var controller in controllers) {
    controller.clear();
  }
}

void disposeAllControllers({required List<TextEditingController> controllers}) {
  for (var controller in controllers) {
    controller.dispose();
  }
}

Future<String> uploadImageToImgbb(File imageFile, String imgbbAPIKey) async {
  final uri = Uri.parse('https://api.imgbb.com/1/upload?key=$imgbbAPIKey');

  final request = http.MultipartRequest('POST', uri)
    ..files.add(await http.MultipartFile.fromPath('image', imageFile.path));

  final response = await request.send();

  if (response.statusCode == 200) {
    final responseBody = await response.stream.bytesToString();
    final jsonData = jsonDecode(responseBody);
    if (jsonData['success']) {
      return jsonData['data']['url'];
    } else {
      throw Exception(
        'Failed to upload image: ${jsonData['error']['message']}',
      );
    }
  } else {
    throw Exception(
      'Failed to upload image. Status code: ${response.statusCode}',
    );
  }
}

void writeDataToCartbox({required String productId}) {
  final int currentQuantity = _cartbox.get(productId, defaultValue: 0);
  _cartbox.put(productId, currentQuantity + 1);
}

void removeDataFromCartbox({required String productId}) {
  final cartItems = _cartbox.values.toList();
  final index = cartItems.indexWhere((item) => item['productId'] == productId);
  _cartbox.deleteAt(index);
}

Future<void> clearCartBox() async {
  await _cartbox.clear();
}

List<Map<String, dynamic>> readDataFromCartbox() {
  final cartItems = _cartbox.values.toList();
  return cartItems.map((item) {
    return {'productId': item['productId'], 'quantity': item['quantity']};
  }).toList();
}
