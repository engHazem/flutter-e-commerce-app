import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xFF0A1931);
  static const Color textfieldColor = Color(0xFF1A3D63);
  static const Color textinputColor = Color(0xFFB3CFE5);
  static const Color buttonColor = Color(0xFF4A7FA7);
  static const Color textColor = Color(0xFFFFFFFF);
}
