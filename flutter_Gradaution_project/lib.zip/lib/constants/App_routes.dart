// ignore_for_file: file_names

class AppRoutes {
  static const String welcome = '/';
  static const String login = '/login';
  static const String signup = '/signup';
  static const String main = '/main';
}
